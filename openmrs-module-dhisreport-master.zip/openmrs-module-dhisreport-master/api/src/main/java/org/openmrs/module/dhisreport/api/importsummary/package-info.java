@XmlSchema( namespace = "http://dhis2.org/schema/dxf/2.0", xmlns = { @XmlNs( namespaceURI = "http://dhis2.org/schema/dxf/2.0", prefix = "d" ) }, elementFormDefault = XmlNsForm.QUALIFIED )
package org.openmrs.module.dhisreport.api.importsummary;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;