@javax.xml.bind.annotation.XmlSchema( namespace = "http://dhis2.org/schema/dxf/2.0", xmlns = { @XmlNs( namespaceURI = "http://dhis2.org/schema/dxf/2.0", prefix = "d" ) }, elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED )
package org.openmrs.module.dhisreport.api.dxf2;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;