package org.openmrs.module.dhisreport.api.dxf2;

/**
 * Created by ICCHANGE on 9/Jan/2017.
 */
public class Disaggregation
{
}
