/**
 *  Copyright 2012 Society for Health Information Systems Programmes, India (HISP India)
 *
 *  This file is part of DHIS2 Reporting module.
 *
 *  DHIS2 Reporting module is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.

 *  DHIS2 Reporting module is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with DHIS2 Reporting module.  If not, see <http://www.gnu.org/licenses/>.
 *
 **/
package org.openmrs.module.dhisreport.web.controller;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hisp.dhis.dxf2.importsummary.ImportSummary;
import org.openmrs.Location;
import org.openmrs.LocationAttribute;
import org.openmrs.api.context.Context;
import org.openmrs.module.dhisreport.api.AggregatedResultSet;
import org.openmrs.module.dhisreport.api.DHIS2ReportingException;
import org.openmrs.module.dhisreport.api.DHIS2ReportingService;
import org.openmrs.module.dhisreport.api.adx.AdxType;
import org.openmrs.module.dhisreport.api.adx.DataValueType;
import org.openmrs.module.dhisreport.api.adx.GroupType;
import org.openmrs.module.dhisreport.api.dhis.Dhis2Server;
import org.openmrs.module.dhisreport.api.dhis.HttpDhis2Server;
import org.openmrs.module.dhisreport.api.dxf2.DataValue;
import org.openmrs.module.dhisreport.api.dxf2.DataValueSet;
import org.openmrs.module.dhisreport.api.importsummary.ImportSummaries;
import org.openmrs.module.dhisreport.api.model.*;
import org.openmrs.module.dhisreport.api.utils.DailyPeriod;
import org.openmrs.module.dhisreport.api.utils.MonthlyPeriod;
import org.openmrs.module.dhisreport.api.utils.Period;
import org.openmrs.module.dhisreport.api.utils.WeeklyPeriod;
import org.openmrs.module.reporting.report.Report;
import org.openmrs.util.LocationUtility;
import org.openmrs.web.WebConstants;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * The main controller.
 */
@Controller
public class ReportController
{

    protected final Log log = LogFactory.getLog( getClass() );

    @RequestMapping( value = "/module/dhisreport/manage", method = RequestMethod.GET )
    public void manage( ModelMap model )
    {
        model.addAttribute( "user", Context.getAuthenticatedUser() );
    }

    @RequestMapping( value = "/module/dhisreport/listDhis2Reports", method = RequestMethod.GET )
    public void listReports( ModelMap model )
    {
        DHIS2ReportingService service = Context.getService( DHIS2ReportingService.class );

        model.addAttribute( "user", Context.getAuthenticatedUser() );
        model.addAttribute( "reportDefinitions", service.getAllReportDefinitions() );
    }

    @RequestMapping( value = "/module/dhisreport/setupReport", method = RequestMethod.GET )
    public void setupReport( ModelMap model, @RequestParam( value = "reportDefinition_id", required = false )
    Integer reportDefinition_id, HttpSession session )
    {
        DHIS2ReportingService service = Context.getService( DHIS2ReportingService.class );
        String errormsg = (String) session.getAttribute( "errorMessage" );
        session.removeAttribute( "errorMessage" );

        model.addAttribute( "user", Context.getAuthenticatedUser() );
        model.addAttribute( "reportDefinition", service.getReportDefinition( reportDefinition_id ) );
        model.addAttribute( "locations", Context.getLocationService().getAllLocations() );
        model.addAttribute( "errorMessage", errormsg );

        String dhisurl = Context.getAdministrationService().getGlobalProperty( "dhisreport.dhis2URL" );
        String dhisusername = Context.getAdministrationService().getGlobalProperty( "dhisreport.dhis2UserName" );
        String dhispassword = Context.getAdministrationService().getGlobalProperty( "dhisreport.dhis2Password" );

        HttpDhis2Server server = service.getDhis2Server();

        URL url = null;
        try
        {
            url = new URL( dhisurl );
        }
        catch ( MalformedURLException e )
        {
            e.printStackTrace();
        }

        server.setUrl( url );
        server.setUsername( dhisusername );
        server.setPassword( dhispassword );

        if ( (server != null) & (server.isConfigured()) )
        {
            model.addAttribute( "dhis2Server", server );
        }
    }

    @RequestMapping( value = "/module/dhisreport/setupBulkReport", method = RequestMethod.GET )
    public void setupBulkReport( ModelMap model, @RequestParam( value = "type", required = false )
    String reportType, HttpSession session )
    {
        DHIS2ReportingService service = Context.getService( DHIS2ReportingService.class );
        String errormsg = (String) session.getAttribute( "errorMessage" );
        session.removeAttribute( "errorMessage" );

        model.addAttribute( "user", Context.getAuthenticatedUser() );
        model.addAttribute( "reportDefinitions", service.getReportDefinitionByPeriodType( reportType ) );
        model.addAttribute( "reportType", reportType );
        model.addAttribute( "locations", Context.getLocationService().getAllLocations() );
        model.addAttribute( "errorMessage", errormsg );

        String dhisurl = Context.getAdministrationService().getGlobalProperty( "dhisreport.dhis2URL" );
        String dhisusername = Context.getAdministrationService().getGlobalProperty( "dhisreport.dhis2UserName" );
        String dhispassword = Context.getAdministrationService().getGlobalProperty( "dhisreport.dhis2Password" );

        HttpDhis2Server server = service.getDhis2Server();

        URL url = null;
        try
        {
            url = new URL( dhisurl );
        }
        catch ( MalformedURLException e )
        {
            e.printStackTrace();
        }

        server.setUrl( url );
        server.setUsername( dhisusername );
        server.setPassword( dhispassword );

        if ( (server != null) & (server.isConfigured()) )
        {
            model.addAttribute( "dhis2Server", server );
        }
    }

    @RequestMapping( value = "/module/dhisreport/executeReport", method = RequestMethod.POST )
    public String executeReport( ModelMap model, @RequestParam( value = "reportDefinition_id", required = true )
    Integer reportDefinition_id, @RequestParam( value = "location", required = false )
    String OU_Code, @RequestParam( value = "resultDestination", required = true )
    String destination, @RequestParam( value = "date", required = true )
    String dateStr, @RequestParam( value = "frequency", required = true )
    String freq, @RequestParam( value = "consecutive", required = true )
    Integer consecutive, @RequestParam( value = "mappingType", required = true )
    String mappingType, WebRequest webRequest, HttpServletRequest request )
        throws Exception
    {
        //get a period from the date string
        Period period = null;
        try
        {
            period = getPeriodFromDateString( freq, dateStr );
        }
        catch ( ParseException pex )
        {
            return "redirect:" + logDateError( webRequest, pex );
        }
        //get period list of consecutive dates after current period up to consecutive value limit
        List<Period> periodList = generatePeriodList( period, consecutive );

        // Get Location by OrgUnit Code
        List<Location> locationListFinal = null;
        try
        {
            locationListFinal = getValidLocationList();
        }
        catch ( Exception e )
        {
            return "redirect:" + logLocationError( webRequest, request );
        }

        ImportSummaries importSummaries = null;
        List<AggregatedResultSet> aggregatedList = new ArrayList<AggregatedResultSet>();

        //set up and run report definition
        for ( Location l : locationListFinal )
        {
            for ( Period periodValue : periodList )
            {
                ReportDefinition report = Context.getService( DHIS2ReportingService.class ).getReportDefinition(
                    reportDefinition_id );

                //send meta data
                aggregatedList.add( sendMetadata( destination, report, l ) );

                //send report
                aggregatedList.add( sendReport( mappingType, destination, report, periodValue, l ) );
            }
        }

        model.addAttribute( "user", Context.getAuthenticatedUser() );
        model.addAttribute( "aggregatedList", aggregatedList );
        return null;
    }

    @RequestMapping( value = "/module/dhisreport/executeBulkReport", method = RequestMethod.POST )
    public String executeBulkReport( ModelMap model, @RequestParam( value = "reportType", required = true )
    String reportType, @RequestParam( value = "location", required = false )
    String OU_Code, @RequestParam( value = "resultDestination", required = true )
    String destination, @RequestParam( value = "date", required = true )
    String dateStr, @RequestParam( value = "frequency", required = true )
    String freq, @RequestParam( value = "consecutive", required = true )
    Integer consecutive, @RequestParam( value = "mappingType", required = true )
    String mappingType, WebRequest webRequest, HttpServletRequest request )
        throws Exception
    {
        DHIS2ReportingService service = Context.getService( DHIS2ReportingService.class );

        //get a period from the date string
        Period period = null;
        try
        {
            period = getPeriodFromDateString( freq, dateStr );
        }
        catch ( ParseException pex )
        {
            return "redirect:" + logDateError( webRequest, pex );
        }

        //get period list of consecutive dates after current period up to consecutive value limit
        List<Period> periodList = generatePeriodList( period, consecutive );

        // Get Location by OrgUnit Code
        List<Location> locationListFinal = null;
        try
        {
            locationListFinal = getValidLocationList();
        }
        catch ( Exception e )
        {
            return "redirect:" + logLocationError( webRequest, request );
        }

        List<AggregatedResultSet> aggregatedList = new ArrayList<AggregatedResultSet>();
        //run reports and metadata
        for ( Location l : locationListFinal )
        {
            for ( Period periodValue : periodList )
            {
                List<ReportDefinition> definitionList = service.getReportDefinitionByPeriodType( reportType );
                for ( ReportDefinition r : definitionList )
                {
                    //send meta data
                    aggregatedList.add( sendMetadata( destination, r, l ) );
                    //send report
                    aggregatedList.add( sendReport( mappingType, destination, r, periodValue, l ) );
                }
            }
        }

        model.addAttribute( "user", Context.getAuthenticatedUser() );
        model.addAttribute( "aggregatedList", aggregatedList );
        return null;
    }

    public Period getPeriodFromDateString( String freq, String dateStr )
        throws ParseException
    {
        Period period = null;
        if ( freq.equalsIgnoreCase( "monthly" ) )
        {
            period = monthly( dateStr );
        }
        if ( freq.equalsIgnoreCase( "weekly" ) )
        {
            period = weekly( dateStr );
        }
        if ( freq.equalsIgnoreCase( "daily" ) )
        {
            period = daily( dateStr );
        }
        return period;
    }

    public List<Period> generatePeriodList( Period period, int consecutive )
    {
        List<Period> periodList = new ArrayList<Period>();
        periodList.add( period );
        for ( int i = 1; i < consecutive; i++ )
        {
            Period nextPeriod = period.getAsIsoStringNextValue( i );
            periodList.add( nextPeriod );
        }
        return periodList;
    }

    public List<Location> getValidLocationList()
        throws Exception
    {
        List<Location> locationList = new ArrayList<Location>();
        List<Location> locationListFinal = new ArrayList<Location>();
        //use below line if not location restricting
        //locationList.addAll( Context.getLocationService().getAllLocations() );
        //use below line if location restricting to current
        locationList.add( LocationUtility.getDefaultLocation() );

        //remove locations without Organization Unit Codes
        for ( Location l : locationList )
        {
            for ( LocationAttribute la : l.getActiveAttributes() )
            {
                if ( la.getAttributeType().getName().equals( "CODE" ) )
                {
                    if ( !la.getValue().toString().isEmpty() && la.getValue().toString() != null )
                    {
                        locationListFinal.add( l );
                        break;
                    }
                }
            }
        }

        if ( locationListFinal.isEmpty() && !locationList.isEmpty() )
        {
            throw new Exception();
        }

        return locationListFinal;
    }

    public AggregatedResultSet sendMetadata( String destination, ReportDefinition report, Location l )
        throws DHIS2ReportingException
    {
        AggregatedResultSet agrs = new AggregatedResultSet();

        DataValueSet dvs = new DataValueSet();
        dvs.setDataSet( "Meta Data export" );
        dvs.setOrgUnit( l.getName() );
        agrs.setDataValueSet( dvs );

        ImportSummaries importSummaries = null;
        for ( DataElementQuery eq : report.getQueries() )
        {
            List<Object[]> metadataelements = Context.getService( DHIS2ReportingService.class )
                .evaluateDataElementQueries( eq, l );
            if ( destination.equals( "post" ) )
            {
                importSummaries = postMetaData( metadataelements, eq );
                //need to get the uids from dhis2 for each element generated
                List<String[]> uids = getDhis2Metadata( metadataelements, eq.getPrefix() );
                for ( MetaDataValueTemplate mdt : report.getMetaDataValueTemplates() )
                {
                    for ( int i = 0; i < uids.size(); i++ )
                    {
                        if ( !contains( report, uids.get( i )[0] ) )
                        {
                            DataElement element = new DataElement();
                            element.setName( uids.get( i )[0] );
                            element.setCode( eq.getCodeprefix() + uids.get( i )[2] );
                            element.setUid( uids.get( i )[1] );
                            Context.getService( DHIS2ReportingService.class ).saveDataElement( element );
                            DataValueTemplate data = new DataValueTemplate();
                            data.setDisaggregation( mdt.getDisaggregation() );
                            data.setDataelement( element );
                            String query = mdt.getQuery();
                            String newquery = query;
                            if ( query.contains( "#metaDataId" ) )
                            {
                                newquery = query.replaceAll( "#metaDataId", ((Integer) (metadataelements.get( i )[0]))
                                    .intValue()
                                    + "" );
                            }
                            data.setQuery( newquery );
                            data.setReportDefinition( report );
                            report.addDataValueTemplate( data );
                        }
                    }
                }
            }
        }
        agrs.setImportSummaries( importSummaries );
        return agrs;
    }

    public ImportSummaries postReport( AdxType adxType )
        throws DHIS2ReportingException
    {
        String standard = Context.getAdministrationService().getGlobalProperty( "dhisreport.dhis2Standard" );
        ImportSummaries importSummaries = null;
        if ( standard.equals( "adx" ) )
        {
            importSummaries = Context.getService( DHIS2ReportingService.class ).postAdxReport( adxType );
        }
        else
        {
            importSummaries = Context.getService( DHIS2ReportingService.class ).postDxf2Report( adxType );
        }
        return importSummaries;
    }

    public AggregatedResultSet sendReport( String mappingType, String destination, ReportDefinition report,
        Period periodValue, Location l )
        throws Exception
    {
        AggregatedResultSet agrs = new AggregatedResultSet();
        // Set OrgUnit code into DataValueSet
        DataValueSet dvs = null;
        if ( mappingType.equalsIgnoreCase( "SQL" ) )
        {
            dvs = Context.getService( DHIS2ReportingService.class ).evaluateReportDefinition( report, periodValue, l );
        }
        else if ( mappingType.equalsIgnoreCase( "Reporting" ) )
        {
            dvs = Context.getService( DHIS2ReportingService.class ).generateReportingReportDefinition( report,
                periodValue, l );
        }

        for ( LocationAttribute la : l.getActiveAttributes() )
        {
            if ( la.getAttributeType().getName().equals( "CODE" ) )
                dvs.setOrgUnit( la.getValue().toString() );
        }

        //
        List<DataValue> datavalue = dvs.getDataValues();
        Map<DataElement, String> deset = new HashMap<DataElement, String>();
        for ( DataValue dv : datavalue )
        {
            DataElement detrmp = Context.getService( DHIS2ReportingService.class ).getDataElementByCode(
                dv.getDataElement() );
            deset.put( detrmp, dv.getValue() );
        }
        agrs.setDataValueSet( dvs );
        agrs.setDataElementMap( deset );
        AdxType adxType = getAdxType( dvs, periodValue.getAsIsoString() );

        //todo
        //dvs.getDataValues().get(0).getCategoryOptionCombo();

        if ( destination.equals( "post" ) )
        {
            ImportSummaries importSummaries = postReport( adxType );
            if ( importSummaries != null )
            {
                agrs.setImportSummaries( importSummaries );
            }
        }
        return agrs;
    }

    // @RequestMapping(value = "/module/dhisreport/executeReport", method =
    // RequestMethod.POST)
    // public void saveReport( ModelMap model,
    // @RequestParam(value = "reportDefinition_id", required = true) Integer
    // reportDefinition_id,
    // @RequestParam(value = "location", required = true) Integer location_id,
    // @RequestParam(value = "resultDestination", required = true) String
    // destination,
    // @RequestParam(value = "date", required = true) String dateStr,
    // HttpServletResponse response )
    // throws ParseException, IOException, JAXBException,
    // DHIS2ReportingException
    // {
    // DHIS2ReportingService service = Context.getService(
    // DHIS2ReportingService.class );
    //
    // MonthlyPeriod period = new MonthlyPeriod( new SimpleDateFormat(
    // "yyyy-MM-dd" ).parse( dateStr ) );
    // Location location = Context.getLocationService().getLocation( location_id
    // );
    //
    // DataValueSet dvs = service.evaluateReportDefinition(
    // service.getReportDefinition( reportDefinition_id ), period, location );
    //
    // response.setContentType( "application/xml" );
    // response.setCharacterEncoding( "UTF-8" );
    // response.addHeader( "Content-Disposition",
    // "attachment; filename=report.xml" );
    //
    // dvs.marshall( response.getOutputStream());
    // }

    @RequestMapping( value = "/module/dhisreport/syncReports", method = RequestMethod.GET )
    public void syncReports( ModelMap model )
    {
        DHIS2ReportingService service = Context.getService( DHIS2ReportingService.class );

        model.addAttribute( "user", Context.getAuthenticatedUser() );
        model.addAttribute( "reportDefinitions", service.getAllReportDefinitions() );
    }

    private String replacedateStrMonth( String dateStr )
    {

        String str = "";
        // System.out.println( dateStr.substring( 5, 8 ) );

        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Jan" ) )
        {
            //System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Jan", "01" );
            // System.out.println( "converting date" + str );
        }
        else if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Feb" ) )
        {
            //  System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Feb", "02" );
            //  System.out.println( "converting date" + str );
        }
        else if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Mar" ) )
        {
            // System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Mar", "03" );
            // System.out.println( "converting date" + str );
        }
        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Apr" ) )
        {
            // System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Apr", "04" );
            // System.out.println( "converting date" + str );
        }
        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "May" ) )
        {
            // System.out.println( "converting date" );
            str = dateStr.replaceFirst( "May", "05" );
            // System.out.println( "converting date" + str );
        }
        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Jun" ) )
        {
            // System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Jun", "06" );
            //  System.out.println( "converting date" + str );
        }
        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Jul" ) )
        {
            //  System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Jul", "07" );
        }
        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Aug" ) )
        {
            // System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Aug", "08" );
            // System.out.println( "converting date" + str );
        }
        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Sep" ) )
        {
            //  System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Sep", "09" );
            // System.out.println( "converting date" + str );
        }
        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Oct" ) )
        {
            // System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Oct", "10" );
            // System.out.println( "converting date" + str );
        }
        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Nov" ) )
        {
            // System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Nov", "11" );
            // System.out.println( "converting date" + str );
        }
        if ( dateStr.substring( 5, 8 ).equalsIgnoreCase( "Dec" ) )
        {
            // System.out.println( "converting date" );
            str = dateStr.replaceFirst( "Dec", "12" );
            //  System.out.println( "converting date" + str );
        }

        return str;
    }

    AdxType getAdxType( DataValueSet dvs, String timeperiod )
    {
        AdxType adxType = new AdxType();
        adxType.setExported( dvs.getCompleteDate() );
        GroupType gt = new GroupType();
        List<DataValueType> dvTypeList = new ArrayList<DataValueType>();
        for ( DataValue dv : dvs.getDataValues() )
        {
            DataValueType dvtype = new DataValueType();
            dvtype.setDataElement( dv.getDataElement() );
            dvtype.setValue( new BigDecimal( dv.getValue() ) );
            dvtype.setCategoryOptionCombo( dv.getCategoryOptionCombo() );
            dvTypeList.add( dvtype );
        }
        gt.getDataValue().addAll( dvTypeList );
        gt.setOrgUnit( dvs.getOrgUnit() );
        gt.setDataSet( dvs.getDataSet() );
        gt.setPeriod( timeperiod );
        adxType.getGroup().add( gt );
        return adxType;
    }

    ImportSummaries postMetaData( List<Object[]> metadataelements, DataElementQuery eq )
        throws DHIS2ReportingException
    {
        //todo generate metadata file
        SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'" );
        Date now = new Date();
        String metadatafile = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
        metadatafile += "<metaData xmlns=\"http://dhis2.org/schema/dxf/2.0\" created=\"" + dateFormat.format( now )
            + "\">";
        metadatafile += "<dataElements>";
        for ( int i = 0; i < metadataelements.size(); i++ )
        {

            metadatafile += "<dataElement ";
            metadatafile += "code=\"" + eq.getCodeprefix() + ((Integer) (metadataelements.get( i )[0])).intValue()
                + "\" ";
            metadatafile += "name=\"" + eq.getPrefix() + ": " + (String) (metadataelements.get( i )[1]) + "\" ";
            metadatafile += "shortName=\"" + eq.getPrefix() + ": " + (String) (metadataelements.get( i )[1]) + "\" ";
            metadatafile += ">";
            metadatafile += "<externalAccess>false</externalAccess>";
            metadatafile += "<aggregationType>SUM</aggregationType>";
            metadatafile += "<dataDimension>true</dataDimension>";
            metadatafile += "<valueType>INTEGER</valueType>";
            metadatafile += "<domainType>AGGREGATE</domainType>";
            metadatafile += "<url></url>";
            metadatafile += "<zeroIsSignificant>false</zeroIsSignificant>";
            metadatafile += "</dataElement>";
            //System.out.println( (String) (metadataelements.get( i )[1]) );
        }
        metadatafile += "</dataElements>";
        metadatafile += "</metaData>";
        //System.out.println( metadatafile );
        return Context.getService( DHIS2ReportingService.class ).postMetaData( metadatafile );

    }

    public List<String[]> getDhis2Metadata( List<Object[]> metadata, String prefix )
    {
        return Context.getService( DHIS2ReportingService.class ).getDataElements( metadata, prefix );
    }

    public boolean contains( ReportDefinition report, String elementName )
    {
        Iterator i = report.getDataValueTemplates().iterator();
        while ( i.hasNext() )
        {
            String test = ((DataValueTemplate) i.next()).getDataelement().getName();
            if ( test.equals( elementName ) )
            {
                return true;
            }
        }
        return false;
    }

    public String logDateError( WebRequest webRequest, ParseException pex )
    {
        log.error( "Cannot convert passed string to date... Please check dateFormat", pex );
        webRequest.setAttribute( WebConstants.OPENMRS_ERROR_ATTR, Context.getMessageSourceService().getMessage(
            "Date Parsing Error" ), WebRequest.SCOPE_SESSION );
        String referer = webRequest.getHeader( "Referer" );
        return referer;
    }

    public String logLocationError( WebRequest webRequest, HttpServletRequest request )
    {
        log.error( "Location attribute CODE not set" );
        request.getSession().setAttribute( "errorMessage", "Please set location attribute CODE to generate results." );
        String referer = webRequest.getHeader( "Referer" );
        return referer;
    }

    public Period monthly( String dateStr )
        throws ParseException
    {
        Period period = null;
        if ( dateStr.length() > 7 )
            dateStr = replacedateStrMonth( dateStr );
        dateStr = dateStr.concat( "-01" );

        //System.out.println( "helloooooooooo1=====" + dateStr );
        period = new MonthlyPeriod( new SimpleDateFormat( "yyyy-MM-dd" ).parse( dateStr ) );
        // System.out.println( "helloooooooooo2=====" + period );

        return period;
    }

    public Period weekly( String dateStr )
        throws ParseException
    {
        Period period = null;
        String finalweek = "";
        String[] modify_week = dateStr.split( "W" );
        Integer weekvalue = Integer.parseInt( dateStr.substring( dateStr.indexOf( 'W' ) + 1 ) ) + 1;
        if ( weekvalue > 9 )
        {
            weekvalue = weekvalue == 54 ? 53 : weekvalue;
            finalweek = modify_week[0].concat( "W" + weekvalue.toString() );
        }
        else
        {
            finalweek = modify_week[0].concat( "W0" + weekvalue.toString() );
        }

        period = new WeeklyPeriod( new SimpleDateFormat( "yyyy-'W'ww" ).parse( finalweek ) );

        return period;
    }

    public Period daily( String dateStr )
        throws ParseException
    {
        Period period = null;

        period = new DailyPeriod( new SimpleDateFormat( "MM/dd/yyyy" ).parse( dateStr ) );

        return period;
    }

}
